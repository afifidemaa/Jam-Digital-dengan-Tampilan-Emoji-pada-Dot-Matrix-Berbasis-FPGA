module jam_digital(
    input clk,
    input S1,
    input S2,
    input S3,
    output reg [7:0] SEG,
    output reg [3:0] DIG,
    output LED0,
	output [7:0] ROW,
	output [7:0] COL
);

wire clk_1hz;
wire [5:0] detik, menit;
wire [4:0] jam;
wire [7:0] seg_wire;
wire clk_matrix;
wire [2:0] row_idx;
wire [2:0] emoji_sel;
wire [7:0] col_data;
wire menit_pulse;
wire ten_sec_pulse;

clock_divider_matrix u_matrix_clock(
    .clk(clk),
    .clk_matrix(clk_matrix)
);

row_scanner u_rowscanner(
    .clk(clk_matrix),
    .reset(S3),
    .row_idx(row_idx)
);

emoji_randomizer u_emojirandomizer(
    .clk_1hz(clk_1hz),
    .reset(S3),
    .detik(detik),
    .emoji_sel(emoji_sel)
);

emoji_rom u_emojirom(
    .emoji_sel(emoji_sel),
    .row_idx(row_idx),
    .col_data(col_data)
);


dotmatrix_driver u_dotmatrixdriver(
    .row_idx(row_idx),
    .col_data(col_data),
    .ROW(ROW),
    .COL(COL)
);

clock_divider u1(.clk(clk), .clk_1hz(clk_1hz));

counter_waktu u_counterwaktu(
    .clk_1hz(clk_1hz),
    .start(S1),
    .stop(S2),
    .reset(S3),
    .detik(detik),
    .menit(menit),
    .jam(jam),
    .ten_sec_pulse(ten_sec_pulse)
);

reg [3:0] digit_val;
reg [1:0] mux_sel;
reg [15:0] mux_counter;

always @(posedge clk) begin
    if (mux_counter == 16'd50000) begin
        mux_counter <= 0;
        mux_sel <= mux_sel + 1;
    end else begin
        mux_counter <= mux_counter + 1;
    end
end

always @(*) begin
    case (mux_sel)
        2'd0: begin DIG = 4'b1110; digit_val = detik % 10; end
        2'd1: begin DIG = 4'b1101; digit_val = detik / 10; end
        2'd2: begin DIG = 4'b1011; digit_val = menit % 10; end
        2'd3: begin DIG = 4'b0111; digit_val = menit / 10; end
    endcase
end

seg_decoder u_segdecoder(.digit(digit_val), .seg(seg_wire));

always @(*) begin
    SEG = seg_wire;
end

assign LED0 = menit_pulse;

endmodule