module counter_waktu(
    input clk_1hz,
    input start,
    input stop,
    input reset,

    output reg [5:0] detik,
    output reg [5:0] menit,
    output reg [4:0] jam,

    output reg ten_sec_pulse
);

reg running;

always @(posedge clk_1hz) begin

    if(!reset) begin
        detik <= 0;
        menit <= 0;
        jam   <= 0;

        running <= 1'b1;
        ten_sec_pulse <= 1'b0;
    end
    else begin

        // START / STOP
        if(!stop)
            running <= 1'b0;
        else if(!start)
            running <= 1'b1;

        ten_sec_pulse <= 1'b0;

        if(running) begin

            // =========================
            // PULSE TIAP 10 DETIK
            // Aktif saat angka yang tampil:
            // 10,20,30,40,50,00
            // =========================
            if(detik == 9  ||
               detik == 19 ||
               detik == 29 ||
               detik == 39 ||
               detik == 49 ||
               detik == 59)
            begin
                ten_sec_pulse <= 1'b1;
            end

            // =========================
            // COUNTER WAKTU
            // =========================
            if(detik == 59) begin

                detik <= 0;

                if(menit == 59) begin

                    menit <= 0;

                    if(jam == 23)
                        jam <= 0;
                    else
                        jam <= jam + 1;

                end
                else begin
                    menit <= menit + 1;
                end

            end
            else begin
                detik <= detik + 1;
            end

        end

    end

end

endmodule