module row_scanner(
    input clk,
    input reset,
    output reg [2:0] row_idx
);

always @(posedge clk) begin
    if(!reset)
        row_idx <= 3'd0;
    else if(row_idx == 3'd7)
        row_idx <= 3'd0;
    else
        row_idx <= row_idx + 1'b1;
end

endmodule