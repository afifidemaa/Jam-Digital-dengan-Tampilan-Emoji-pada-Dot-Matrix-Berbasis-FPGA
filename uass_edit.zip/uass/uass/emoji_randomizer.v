module emoji_randomizer(
    input clk_1hz,
    input reset,
    input [5:0] detik,
    output reg [2:0] emoji_sel
);

always @(posedge clk_1hz) begin

    if(!reset) begin
        emoji_sel <= 3'd0;
    end
    else begin

        if(
            detik == 9  ||
            detik == 19 ||
            detik == 29 ||
            detik == 39 ||
            detik == 49 ||
            detik == 59
        )
        begin

            if(emoji_sel == 3'd5)
                emoji_sel <= 3'd0;
            else
                emoji_sel <= emoji_sel + 3'd1;

        end

    end

end

endmodule