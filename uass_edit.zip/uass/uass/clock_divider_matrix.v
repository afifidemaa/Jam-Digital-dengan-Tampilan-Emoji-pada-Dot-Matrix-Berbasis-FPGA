module clock_divider_matrix(
    input clk,
    output reg clk_matrix
);

reg [15:0] counter;

always @(posedge clk) begin
    if(counter == 16'd25000) begin
        counter <= 0;
        clk_matrix <= ~clk_matrix;
    end
    else begin
        counter <= counter + 1;
    end
end

endmodule