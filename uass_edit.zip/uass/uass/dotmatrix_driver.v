module dotmatrix_driver(
    input [2:0] row_idx,
    input [7:0] col_data,
    output reg [7:0] ROW,
    output reg [7:0] COL
);

always @(*) begin

    ROW = 8'b11111111;
    COL = 8'b00000000;

    ROW[row_idx] = 1'b0;

    COL = col_data;

end

endmodule