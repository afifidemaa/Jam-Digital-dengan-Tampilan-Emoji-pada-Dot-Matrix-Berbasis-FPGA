module emoji_rom(
    input [2:0] emoji_sel,
    input [2:0] row_idx,
    output reg [7:0] col_data
);

always @(*) begin

case(emoji_sel)

//
// 0 = Target
//
3'd0:
case(row_idx)
0: col_data = 8'b00111100;
        1: col_data = 8'b01000010;
        2: col_data = 8'b10011001;
        3: col_data = 8'b10111101;
        4: col_data = 8'b10111101;
        5: col_data = 8'b10011001;
        6: col_data = 8'b01000010;
        7: col_data = 8'b00111100;
endcase

//
// 1 = checker
//
3'd1:
case(row_idx)
  0: col_data = 8'b11111111;
        1: col_data = 8'b01111110;
        2: col_data = 8'b00111100;
        3: col_data = 8'b00011000;
        4: col_data = 8'b00011000;
        5: col_data = 8'b00111100;
        6: col_data = 8'b01111110;
        7: col_data = 8'b11111111;
endcase

//
// 2 = HEART
//
3'd2:
case(row_idx)
0: col_data = 8'b01100110;
1: col_data = 8'b11111111;
2: col_data = 8'b11111111;
3: col_data = 8'b11111111;
4: col_data = 8'b01111110;
5: col_data = 8'b00111100;
6: col_data = 8'b00011000;
7: col_data = 8'b00000000;
endcase

//
// 3 = UP ARROW
//
3'd3:
case(row_idx)
0: col_data = 8'b00011000;
1: col_data = 8'b00111100;
2: col_data = 8'b01111110;
3: col_data = 8'b11011011;
4: col_data = 8'b00011000;
5: col_data = 8'b00011000;
6: col_data = 8'b00011000;
7: col_data = 8'b00000000;
endcase

//
// 4 = DIAMOND
//
3'd4:
case(row_idx)
0: col_data = 8'b00011000;
1: col_data = 8'b00111100;
2: col_data = 8'b01111110;
3: col_data = 8'b11111111;
4: col_data = 8'b01111110;
5: col_data = 8'b00111100;
6: col_data = 8'b00011000;
7: col_data = 8'b00000000;
endcase

//
// 5 = STAR
//
3'd5:
case(row_idx)
0: col_data = 8'b00011000;
1: col_data = 8'b10011001;
2: col_data = 8'b01011010;
3: col_data = 8'b00111100;
4: col_data = 8'b00111100;
5: col_data = 8'b01011010;
6: col_data = 8'b10011001;
7: col_data = 8'b00011000;
endcase

default:
    col_data = 8'b00000000;

endcase

end

endmodule